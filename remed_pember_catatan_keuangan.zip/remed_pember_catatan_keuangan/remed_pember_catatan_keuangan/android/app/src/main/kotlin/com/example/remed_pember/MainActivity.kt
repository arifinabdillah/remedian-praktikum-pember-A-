package com.example.remed_pember

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
