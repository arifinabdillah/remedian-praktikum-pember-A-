import 'package:flutter/material.dart';

Color kPrimaryColor = Color(0xFF508C9B);
Color kBlackColor = Color(0xff000000);
Color kWhiteColor = Color(0xffffffff);
Color kSecondColor = Color(0xFF201E43);
Color kBackgroundColor = Color(0xffFAFAFA);

TextStyle blackTextStyle = TextStyle(color: kBlackColor);
TextStyle whiteTextStyle = TextStyle(color: kWhiteColor);
TextStyle primaryTextStyle = TextStyle(color: kPrimaryColor);

FontWeight light = FontWeight.w300;
FontWeight regular = FontWeight.w400;
FontWeight medium = FontWeight.w500;
FontWeight semiBold = FontWeight.w600;
FontWeight bold = FontWeight.w700;
