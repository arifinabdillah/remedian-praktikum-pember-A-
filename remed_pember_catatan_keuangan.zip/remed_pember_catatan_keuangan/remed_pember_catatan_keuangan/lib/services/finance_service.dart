import 'package:remed_pember/models/finance_model.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class FinanceService {
  final String baseUrl =
      "https://test-rest-api-247ff-default-rtdb.firebaseio.com/finalcial-records";

  Future<List<FinanceModel>> getFinances() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl.json'));

      if (response.statusCode == 200) {
        final rawData = json.decode(response.body);

        if (rawData == null || rawData is! Map<String, dynamic>) {
          return [];
        }

        final List<FinanceModel> finances = [];

        rawData.forEach((id, item) {
          if (item is Map<String, dynamic>) {
            finances.add(
              FinanceModel(
                id: id,
                title: item['title'] ?? "",
                type: item['type'] ?? "",
                date: item['date'] ?? "",
                amount: item['amount'] ?? 0,
                description: item['description'] ?? "",
              ),
            );
          }
        });

        return finances;
      } else {
        throw Exception('gagal memuat data: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('terjadi kesalahan : $e');
    }
  }

  Future<FinanceModel?> getFinanceDetail(String id) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/$id.json'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data == null || data is! Map<String, dynamic>) {
          return null;
        }
        return FinanceModel(
          id: id,
          title: data['title'] ?? "",
          type: data['type'] ?? "",
          date: data['date'] ?? "",
          amount: data['amount'] ?? 0,
          description: data['description'] ?? "",
        );
      } else {
        throw Exception('gagal memuat detail: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('terjadi kesalahan : $e');
    }
  }

  Future<void> addFinance(FinanceModel finance) async {
    await http.post(
      Uri.parse('$baseUrl.json'),
      body: json.encode(finance.toJson()),
    );
  }
}
