class FinanceModel {
  final String id;
  final String title;
  final String type;
  final String date;
  final int amount;
  final String description;

  FinanceModel({
    required this.id,
    required this.title,
    required this.type,
    required this.date,
    required this.amount,
    this.description = '',
  });

  factory FinanceModel.fromJson(Map<String, dynamic> json) {
    return FinanceModel(
      id: json['id'],
      title: json['title'],
      type: json['type'],
      date: json['date'],
      amount: json['amount'],
      description: json['description'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'type': type,
      'date': date,
      'amount': amount,
      'description': description,
    };
  }
}
