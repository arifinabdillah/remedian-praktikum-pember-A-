import 'package:flutter/material.dart';
import 'package:remed_pember/shared/theme.dart';
import 'package:remed_pember/services/finance_service.dart';
import 'package:remed_pember/models/finance_model.dart';
import 'package:remed_pember/ui/pages/detail_data_page.dart';
import 'package:remed_pember/ui/widgets/card_financial.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<FinanceModel>> _futureFinances;

  @override
  void initState() {
    super.initState();
    _futureFinances = FinanceService().getFinances();
  }

  int calculateSaldo(List<FinanceModel> finances) {
    int saldo = 0;
    for (var item in finances) {
      if (item.type.toLowerCase() == "pemasukan") {
        saldo += item.amount;
      } else if (item.type.toLowerCase() == "pengeluaran") {
        saldo -= item.amount;
      }
    }
    return saldo;
  }

  Future<void> _navigateAndRefresh(BuildContext context) async {
    await Navigator.pushNamed(context, '/add');
    setState(() {
      _futureFinances = FinanceService().getFinances();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: FutureBuilder<List<FinanceModel>>(
          future: _futureFinances,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(
                child: Text(
                  "Gagal memuat data: ${snapshot.error}",
                  style: const TextStyle(color: Colors.red),
                ),
              );
            }

            // Saat tidak ada data
            final finances = snapshot.data ?? [];
            final saldo = calculateSaldo(finances);

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Saldo: $saldo",
                  style: blackTextStyle.copyWith(
                    fontWeight: bold,
                    fontSize: 24,
                  ),
                ),
                const SizedBox(height: 10),
                if (finances.isEmpty)
                  const Expanded(child: Center(child: Text("Belum ada data")))
                else
                  Expanded(
                    child: ListView.builder(
                      itemCount: finances.length,
                      itemBuilder: (context, index) {
                        final item = finances[index];
                        return CardFinancial(
                          title: item.title,
                          jenis: item.type,
                          date: item.date,
                          value: item.amount,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder:
                                    (context) => DetailDataPage(id: item.id),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
              ],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kSecondColor,
        child: Icon(Icons.add, color: kWhiteColor),
        onPressed: () => _navigateAndRefresh(context),
      ),
    );
  }
}
