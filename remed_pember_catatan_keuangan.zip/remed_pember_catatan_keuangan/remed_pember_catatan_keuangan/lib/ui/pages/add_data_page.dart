import 'package:flutter/material.dart';
import 'package:remed_pember/models/finance_model.dart';
import 'package:remed_pember/services/finance_service.dart';
import 'package:remed_pember/shared/theme.dart';
import 'package:remed_pember/ui/widgets/custom_date_form_field.dart';
import 'package:remed_pember/ui/widgets/custom_dropdown_form_field.dart';
import 'package:remed_pember/ui/widgets/custom_form_field.dart';

class AddDataPage extends StatefulWidget {
  const AddDataPage({super.key});

  @override
  State<AddDataPage> createState() => _AddDataPageState();
}

class _AddDataPageState extends State<AddDataPage> {
  String? selectedJenis;

  final formKey = GlobalKey<FormState>();

  final TextEditingController titleController = TextEditingController();
  final TextEditingController typeController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  final TextEditingController amountController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: kBackgroundColor,
        title: Text(
          "Tambah Data",
          style: blackTextStyle.copyWith(fontWeight: bold, fontSize: 24),
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Form(
            key: formKey,
            child: Column(
              children: [
                Center(
                  child: Container(
                    width: 150,
                    height: 150,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.asset(
                        "assets/images/Image - Test.jpg",
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                CustomFormField(title: "Title", controller: titleController),
                CustomDropdownFormField(
                  title: "Jenis",
                  value: selectedJenis,
                  items: [
                    DropdownMenuItem(
                      value: "Pemasukan",
                      child: Text("Pemasukan"),
                    ),
                    DropdownMenuItem(
                      value: "Pengeluaran",
                      child: Text("Pengeluaran"),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() {
                      selectedJenis = value;
                    });
                  },
                ),
                CustomDateFormField(
                  title: "Tanggal",
                  controller: dateController,
                  onTap: () async {
                    DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (picked != null) {
                      // Format tanggal sesuai kebutuhan, contoh:
                      dateController.text =
                          "${picked.day}-${picked.month}-${picked.year}";
                    }
                  },
                ),
                CustomFormField(title: "Jumlah", controller: amountController),
                CustomFormField(
                  title: "Deskripsi",
                  maxLines: 4,
                  controller: descriptionController,
                ),
                GestureDetector(
                  onTap: () async {
                    if (formKey.currentState!.validate()) {
                      try {
                        final newFinance = FinanceModel(
                          id: '',
                          title: titleController.text,
                          type: selectedJenis!,
                          date: dateController.text,
                          amount: int.tryParse(amountController.text) ?? 0,
                          description: descriptionController.text,
                        );

                        await FinanceService().addFinance(newFinance);

                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Data berhasil disimpan")),
                        );

                        Navigator.pop(context);
                      } catch (e) {
                        ScaffoldMessenger.of(
                          context,
                        ).showSnackBar(SnackBar(content: Text(e.toString())));
                      }
                    }
                  },
                  child: Container(
                    width: double.infinity,
                    height: 40,
                    decoration: BoxDecoration(
                      color: kSecondColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      "Simpan",
                      style: whiteTextStyle.copyWith(fontWeight: bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
