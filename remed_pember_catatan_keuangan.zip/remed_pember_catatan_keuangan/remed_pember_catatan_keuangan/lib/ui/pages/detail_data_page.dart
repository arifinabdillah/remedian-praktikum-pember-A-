import 'package:flutter/material.dart';
import 'package:remed_pember/services/finance_service.dart';
import 'package:remed_pember/models/finance_model.dart';
import 'package:remed_pember/ui/widgets/custom_form_field.dart';
import 'package:remed_pember/shared/theme.dart';

class DetailDataPage extends StatelessWidget {
  final String id;
  const DetailDataPage({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        title: Text(
          'Detail Catatan',
          style: blackTextStyle.copyWith(fontWeight: bold, fontSize: 24),
        ),
        centerTitle: true,
      ),
      body: FutureBuilder<FinanceModel?>(
        future: FinanceService().getFinanceDetail(id),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(
              child: Text('Gagal memuat detail: ${snapshot.error}'),
            );
          } else if (!snapshot.hasData || snapshot.data == null) {
            return const Center(child: Text('Data tidak ditemukan'));
          }

          final finance = snapshot.data!;
          return SingleChildScrollView(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Column(
                children: [
                  Center(
                    child: Container(
                      width: 150,
                      height: 150,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.asset(
                          "assets/images/Image - Test.jpg",
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  CustomFormField(
                    title: "Title",
                    controller: TextEditingController(text: finance.title),
                    readOnly: true,
                  ),
                  CustomFormField(
                    title: "Jenis",
                    controller: TextEditingController(text: finance.type),
                    readOnly: true,
                  ),
                  CustomFormField(
                    title: "Tanggal",
                    controller: TextEditingController(text: finance.date),
                    readOnly: true,
                  ),
                  CustomFormField(
                    title: "Jumlah",
                    controller: TextEditingController(
                      text: finance.amount.toString(),
                    ),
                    readOnly: true,
                  ),
                  CustomFormField(
                    title: "Deskripsi",
                    controller: TextEditingController(
                      text: finance.description,
                    ),
                    readOnly: true,
                    maxLines: 4,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
