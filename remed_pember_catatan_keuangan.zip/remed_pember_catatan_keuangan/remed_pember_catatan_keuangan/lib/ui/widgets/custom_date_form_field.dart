import 'package:flutter/material.dart';
import 'package:remed_pember/shared/theme.dart';

class CustomDateFormField extends StatelessWidget {
  final String title;
  final TextEditingController controller;
  final void Function()? onTap;

  const CustomDateFormField({
    Key? key,
    required this.title,
    required this.controller,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: blackTextStyle.copyWith(fontSize: 16, fontWeight: bold),
          ),
          const SizedBox(height: 2),
          TextFormField(
            controller: controller,
            style: whiteTextStyle,
            onTap: onTap,
            decoration: InputDecoration(
              filled: true,
              fillColor: kPrimaryColor,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 10,
              ),
              suffixIcon: const Icon(Icons.calendar_today, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
