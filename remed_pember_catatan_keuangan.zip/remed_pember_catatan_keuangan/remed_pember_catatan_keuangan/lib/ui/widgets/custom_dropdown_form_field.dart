import 'package:flutter/material.dart';
import 'package:remed_pember/shared/theme.dart';

class CustomDropdownFormField<T> extends StatelessWidget {
  final String title;
  final List<DropdownMenuItem<T>> items;
  final T? value;
  final void Function(T?)? onChanged;

  const CustomDropdownFormField({
    Key? key,
    required this.title,
    required this.items,
    this.value,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: blackTextStyle.copyWith(fontSize: 16, fontWeight: bold),
          ),
          const SizedBox(height: 2),
          DropdownButtonFormField<T>(
            value: value,
            items: items,
            onChanged: onChanged,
            dropdownColor: kPrimaryColor,
            style: whiteTextStyle,
            decoration: InputDecoration(
              filled: true,
              fillColor: kPrimaryColor,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 10,
              ),
            ),
            iconEnabledColor: Colors.white,
          ),
        ],
      ),
    );
  }
}
