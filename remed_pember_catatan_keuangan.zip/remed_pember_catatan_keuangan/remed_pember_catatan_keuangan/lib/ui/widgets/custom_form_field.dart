import 'package:flutter/material.dart';
import 'package:remed_pember/shared/theme.dart';

class CustomFormField extends StatelessWidget {
  final String title;
  final int? maxLines;
  final TextEditingController? controller;
  final bool readOnly;

  const CustomFormField({
    super.key,
    required this.title,
    this.maxLines = 1,
    this.controller,

    this.readOnly = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: blackTextStyle.copyWith(fontSize: 16, fontWeight: bold),
          ),
          SizedBox(height: 2),
          TextFormField(
            readOnly: readOnly,
            controller: controller,
            maxLines: maxLines,
            style: whiteTextStyle,
            decoration: InputDecoration(
              filled: true,
              fillColor: kPrimaryColor,

              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),

              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 10,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
