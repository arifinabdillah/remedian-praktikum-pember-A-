import 'package:flutter/material.dart';
import 'package:remed_pember/shared/theme.dart';

class CardFinancial extends StatelessWidget {
  final String title;
  final String jenis;
  final String date;
  final int value;
  final VoidCallback? onTap; // Tambahkan onTap agar bisa navigate ke detail

  const CardFinancial({
    super.key,
    required this.title,
    required this.jenis,
    required this.date,
    required this.value,
    this.onTap, // Constructor onTap
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 140,
        margin: const EdgeInsets.only(top: 10),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: kPrimaryColor,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  "assets/images/Image - Test.jpg",
                  width: 100,
                  height: 100,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: whiteTextStyle.copyWith(
                        fontWeight: semiBold,
                        fontSize: 16,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      jenis,
                      style: whiteTextStyle.copyWith(fontWeight: regular),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      "Tanggal: $date",
                      style: whiteTextStyle.copyWith(fontWeight: regular),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "Rp. ${value.toString()}",
                      style: whiteTextStyle.copyWith(
                        fontWeight: semiBold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
