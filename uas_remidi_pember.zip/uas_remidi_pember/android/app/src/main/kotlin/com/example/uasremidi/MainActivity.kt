package com.example.uasremidi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
